# Brave Search Goggles contributing guide

This repository is meant exclusively as a way to demonstrate the ways Goggles can be leveraged to change the ranking of Brave Search. As such, it contains
*educational material only* that we do not intend to maintain over time.

Goggles is about the community, Brave is only providing the host search engine to apply them, and we hope that other search engines will follow.

If you create a Goggle it can be hosted in your account, so that you are the sole owner of it. Alternatively, you can share the ownership of Goggles by creating an account or a repository where other people can contribute and help maintain the instructions. It will be accessible and usable by anyone, both in the discovery page or by sharing them as Brave Search URLs with your Goggle URL as `goggles_id` query parameter.
